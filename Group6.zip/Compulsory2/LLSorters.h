﻿#pragma once
#include "LinkedList.h"

void swap();

void selectionSort(Node* Head, int size);

void insertionSort(Node* Head);
